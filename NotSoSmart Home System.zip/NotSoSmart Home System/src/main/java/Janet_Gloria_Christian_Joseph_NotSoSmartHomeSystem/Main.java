package Janet_Gloria_Christian_Joseph_NotSoSmartHomeSystem;

public class Main {
	public static void main(String[] args) {
		
		WeatherUI Weather = new WeatherUI();
		WeatherSensor weatherSensor = new WeatherSensor(25, 10);
		
		weatherSensor.registerObserver(Weather);

		weatherSensor.startWeatherSensor();
	}
}
