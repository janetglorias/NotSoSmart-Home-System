package Janet_Gloria_Christian_Joseph_NotSoSmartHomeSystem;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.text.DecimalFormat;
import java.util.Observable;
import java.util.Observer;

public class WeatherUI implements Observer {
	
	DecimalFormat f = new DecimalFormat("#.##");
	
	private JLabel label, label2;

	public WeatherUI() {

		JFrame j = new JFrame();
		
		j.setTitle("Weather Outside (Powered by Sensors)");
		j.setSize(400, 400);
		j.setLayout(null);
		j.setVisible(true);

		JLabel wind = new JLabel("Wind Speed: ");
		wind.setBounds(50, 40, 200, 40);
		j.add(wind);

		label = new JLabel("99999");
		label.setBounds(150, 40, 200, 40);
		j.add(label);

		JLabel temperature = new JLabel("Temperature: ");
		temperature.setBounds(50, 50, 200, 50);
		j.add(temperature);

		label2 = new JLabel("40");
		label2.setBounds(150, 50, 200, 50);
		j.add(label2);
	}

	@Override
	public void update(Observable sensor, Object arg1) {
		WeatherSensor ws = (WeatherSensor) sensor;
		label.setText(f.format(ws.getWindSpeed()) + " Kilometres per Hour");
		label2.setText(f.format(ws.getTemperature()) + " Degrees Celcius");
	}
}