package Janet_Gloria_Christian_Joseph_NotSoSmartHomeSystem;

import java.util.Observable;
import java.util.Observer;

public class Actors extends Observable{
	
	String WindowStatus;
	String AcStatus;
	
	public Actors(String WindowStatus, String AcStatus) {
		this.WindowStatus = WindowStatus;
		this.AcStatus = AcStatus;
	}
	
	public void registerObserver(Observer o) {
		addObserver(o);
	}
	
	public String getWindowStatus() {
		return WindowStatus;
	}
	
	public void setWindowStatus(String WindowStatus) {
		this.WindowStatus = WindowStatus;
		setChanged();
		notifyObservers(this);
	}
	
	public String getAcStatus() {
		return AcStatus;
	}
	
	public void setAcStatus(String AcStatus) {
		this.AcStatus = AcStatus;
		setChanged();
		notifyObservers(this);
	}
	
	public void startActors() {
		Thread thread = new Thread(new Runnable() {
			@Override
			public void run() {
				while (true) {
					
					setWindowStatus(WindowStatus);
					setAcStatus(AcStatus);
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		});
		
		thread.start();
	}
}
