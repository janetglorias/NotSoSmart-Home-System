package Janet_Gloria_Christian_Joseph_NotSoSmartHomeSystem;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class WeatherData {

	int secondsPassed;

	double windSpeed;
	double temperature;
	//double humidity;

	String windowStatus;
	String acStatus;
	
	ArrayList<WeatherData> WeatherDataArray = new ArrayList<WeatherData>();
	
	DecimalFormat f = new DecimalFormat("#.##");

	public WeatherData(int secondsPassed, double windSpeed, double temperature, String windowStatus, String acStatus) {
		this.secondsPassed = secondsPassed;
		this.windSpeed = windSpeed;
		this.temperature = temperature;
		//this.humidity = humidity;
		this.windowStatus = windowStatus;
		this.acStatus = acStatus;
	}
	
	public void printWeahterData() {
		
		for (int i = 0; i<WeatherDataArray.size(); i++) {
			System.out.println("Hours Passed: " + WeatherDataArray.get(i).secondsPassed +":00" + ", WindSpeed: " + f.format(WeatherDataArray.get(i).windSpeed) + 
					", Temperature: " + f.format(WeatherDataArray.get(i).temperature) +", Window Status: " + WeatherDataArray.get(i).windowStatus + 
					", AC Status: " + WeatherDataArray.get(i).acStatus);
		}
	}
}
