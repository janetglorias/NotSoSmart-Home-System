package Janet_Gloria_Christian_Joseph_NotSoSmartHomeSystem;

import java.util.Timer;
import java.util.TimerTask;

public class WeatherTimer {
	int TimePassed = 0;
	
	public void WeahterTimer(int TimePassed) {
		this.TimePassed = TimePassed;
	}
	
	public int getSecondsPassed() {
		return TimePassed;
	}
	
	public void setSecondsPassed(int TimePassed) {
		this.TimePassed = TimePassed;
	}
	
	Timer mainTimer = new Timer();
	TimerTask Timertask = new TimerTask() {
		public void run() {
			TimePassed++;
		}
	};

	public void start() {
		mainTimer.scheduleAtFixedRate(Timertask, 1000, 1000);
	}
	
}
