package Janet_Gloria_Christian_Joseph_NotSoSmartHomeSystem;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.util.Observable;
import java.util.Observer;

public class ActorsUI implements Observer {
	
private JLabel label1, label2;
    
    public ActorsUI() {
        
        JFrame jframe= new JFrame();
        
        jframe.setTitle("Blinds and Air Conditioner Status");
        jframe.setSize(400, 400);
        jframe.setLayout(null);
        jframe.setVisible(true);
        
        JLabel acLabel = new JLabel("Air Conditioner: ");
        acLabel.setBounds(50, 40, 200, 40);
        
        jframe.add(acLabel);
        
        label1 = new JLabel("CLOSED");
        label1.setBounds(150, 30, 200, 40);
        jframe.add(label1);
        
        JLabel windowLabel = new JLabel("Blinds Status: ");
        windowLabel.setBounds(50, 40, 200, 20);
        
        jframe.add(windowLabel);
        
        label2 = new JLabel("OFF");
        label2.setBounds(150, 40, 200, 50);
        jframe.add(label2);
    }
    
    @Override
    public void update(Observable actor, Object args) {
    	Actors actor1 = (Actors) actor;
    	
    	label1.setText(actor1.getWindowStatus());
    	label2.setText(actor1.getAcStatus());
    }
}
