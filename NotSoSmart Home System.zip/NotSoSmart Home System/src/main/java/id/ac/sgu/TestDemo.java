package id.ac.sgu;

public class TestDemo {

	public int calc(int i, int j) {
		return i + j;
	}

}
